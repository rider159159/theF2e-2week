import { loadingStore } from './loading'

const stores = {
  loadingStore
}

export default stores