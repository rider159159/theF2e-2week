<template>
  <div>
    <div class="w-full h-screen flex items-center justify-center">
      <router-link to="/createSign" class="mr-2">sign</router-link>
      <router-link to="/step1" class="mr-2">step1</router-link>
    </div>
  </div>
</template>
