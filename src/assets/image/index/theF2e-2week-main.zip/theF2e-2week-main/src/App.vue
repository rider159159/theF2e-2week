<template>
  <div class="w-full mx-auto overflow-x-hidden min-h-[calc(100vh-80px)] bg-[#f4f4f4]">
    <RouterView />
  </div>
</template>
